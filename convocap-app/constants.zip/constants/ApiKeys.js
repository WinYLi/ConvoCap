export default {
  FirebaseConfig : {
    apiKey: "AIzaSyDdyiPy6_3L7_vZXv4h7wvlqzYS2M9lo1M",
    authDomain: "convocapp-29bc1.firebaseapp.com",
    databaseURL: "https://convocapp-29bc1.firebaseio.com",
    projectId: "convocapp-29bc1",
    storageBucket: "convocapp-29bc1.appspot.com",
  }
}